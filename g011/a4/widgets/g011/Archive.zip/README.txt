Please submit a README.txt file in the same directory as your javascript file.  Consider including stuff like preferred browser, what TAs should look for (both in the UI and under the hood), any dependencies (e.g. only works if you have a Twitter account), etc.

Given the open-endedness of the assignment, it's critical.
 
Stuff to consider including:
Preferred browser (one of {firefox, chrome, safari})
What to look for:  cool stuff that you did, either in the interface or under the hood.
If there are any particular dependencies to watch out for -- must have a twitter account or ...
 
Please put it in the same directory as your javascript code.